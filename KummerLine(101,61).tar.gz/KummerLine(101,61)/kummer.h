#ifndef KUMMER_H_
#define KUMMER_H_

inline void mul_gfe(gfe *r32, gfe *m, gfe *n);
inline void sq_gfe(gfe *r32, gfe *m);
inline unsigned int gt0(gfe *m);
inline unsigned int ugtv(gfe *m, gfe *n);
inline void div2(gfe *m);
inline void mul2(gfe *m);
inline void addp(gfe *m, gfe *p);
inline void subuv(gfe *op, gfe *m, gfe *n);
inline void adduv(gfe *op, gfe *m, gfe *n);
inline void invert(gfe *op, gfe *m);


inline void gfe4x_permute(gfe4x *op,gfe4x *ip, int hl);
inline void gfe4x_hadamard(gfe4x *op, gfe4x *ip);
inline void mul_gfe4(gfe4x *r64, gfe4x *m, gfe4x *n);
inline void sq_gfe4(gfe4x *r64, gfe4x *m);
inline void mulconst_gfe4(gfe4x *r64, gfe4x *a, const vec *b);
inline u32 scalar_mult_fixed_base(unsigned char op[32], gfe4x base, unsigned char n[31]);
inline u32 scalar_mult_var_base(unsigned char op[32], unsigned char base_rand[64], unsigned char n[31]);

inline u32 scalar_mult_fixed_base(unsigned char op[32], gfe4x base, unsigned char n[31]){
	int bit, i, j, k;
	gfe4x np,npt;
	gfe re[4],x,z,temp,xinvz;
	
	np = base;
	
	bit = 0;
	j = 7;	
	while(bit == 0){
		bit = (n[30]>>j) & 1;
		j--;
	}
	k = 1;
  	for(i=30;i>=0;i--){
    		for(;j>=0;j--){
			bit = (n[i]>>j) & 1;
			gfe4x_hadamard(&np, &np);
			gfe4x_permute(&npt,&np,bit);
			mul_gfe4(&np, &np, &npt);
			mulconst_gfe4(&np, &np, &BABA);
			gfe4x_hadamard(&np, &np);
			sq_gfe4(&np, &np);
			mulconst_gfe4(&np, &np, &abxz[bit]);
		}
		j=7;
	}
	gfe4_t_gfe(&np, re);
	x = re[0];
	z = re[1];
	invert(&temp,&z);
	mul_gfe(&temp,&x,&temp);
	convert_itoc(&temp,op);

	return xinvz.v[0];

}

inline u32 scalar_mult_var_base(unsigned char op[32], unsigned char base_rand[64], unsigned char n[31]){
	int bit, i, j, k;
	gfe4x np,npt;
	gfe work[4],re[4],x,z,temp,xinvz;
	gfe4x temp2,pabxz[2],pzxba;
		
	convert_ctoi(&work[0],base_rand);
	convert_ctoi(&work[1],base_rand+32);
	set_base_point(pabxz,work);
	gfe4_f_gfe_part1(&np, work);
	gfe4x_hadamard(&np, &np);
	sq_gfe4(&np, &np);
	mulconst_gfe4(&np, &np, &BABA);
	gfe4x_hadamard(&np, &np);
	sq_gfe4(&np, &np);
	mulconst_gfe4(&np, &np, &ab11);
	gfe4_f_gfe_part2(&np, work);

	bit = 0;
	j = 7;	
	while(bit == 0){
		bit = (n[30]>>j) & 1;
		j--;
	}
	k = 1;
	
	
  	for(i=30;i>=0;i--){
    		for(;j>=0;j--){
			bit = (n[i]>>j) & 1;
			gfe4x_hadamard(&np, &np);
			gfe4x_permute(&npt,&np,bit);
			mul_gfe4(&np, &np, &npt);
			mulconst_gfe4(&np, &np, &BABA);
			gfe4x_hadamard(&np, &np);
			sq_gfe4(&np, &np);
			mul_gfe4(&np, &np, &pabxz[bit]);
		}
		j=7;
	}
	gfe4_t_gfe(&np, re);
	x = re[0];
	z = re[1];
	invert(&temp,&z);
	mul_gfe(&temp,&x,&temp);
	convert_itoc(&temp,op);

	return xinvz.v[0];

}

inline void gfe4x_permute(gfe4x *op,gfe4x *ip, int hl){
	int i,a,b;
	int hl0,hl1,hl2,hl3;
	hl0 = 4*hl; hl1 = hl0+1; hl2 = hl0+2; hl3 = hl0+3;
	vec perm_mask = _mm256_set_epi32(hl3,hl2,hl1,hl0,hl3,hl2,hl1,hl0);
	op->v[0] = _mm256_permutevar8x32_epi32(ip->v[0],perm_mask);
	op->v[1] = _mm256_permutevar8x32_epi32(ip->v[1],perm_mask);
	op->v[2] = _mm256_permutevar8x32_epi32(ip->v[2],perm_mask);
	op->v[3] = _mm256_permutevar8x32_epi32(ip->v[3],perm_mask);
	op->v[4] = _mm256_permutevar8x32_epi32(ip->v[4],perm_mask);
	op->v[5] = _mm256_permutevar8x32_epi32(ip->v[5],perm_mask);
	op->v[6] = _mm256_permutevar8x32_epi32(ip->v[6],perm_mask);
	op->v[7] = _mm256_permutevar8x32_epi32(ip->v[7],perm_mask);
	op->v[8] = _mm256_permutevar8x32_epi32(ip->v[8],perm_mask);
}

inline void mul_gfe(gfe *r32, gfe *m, gfe *n){
	u32 f0 = m->v[0];
	u32 f1 = m->v[1];
	u32 f2 = m->v[2];
	u32 f3 = m->v[3];
	u32 f4,f5;

	u32 g0 = n->v[0];
	u32 g1 = n->v[1];
	u32 g2 = n->v[2];
	u32 g3 = n->v[3];
	u32 g4,g5;

	u64 h0_t0,h1_t0,h2_t0,h3_t0,h4_t0,h5_t0,h6_t0;
	u64 h0,h1,h2,h3,h4,h5,h6,h7;
	u64 h0_1,h1_1,h2_1,h3_1,h4_1,h5_1,h6_1,h7_1;
	u64 h0_2,h1_2,h2_2;
	h0 = f0*(u64)g0;
	h2 = f1*(u64)g1;
	h1 = (f0+f1)*(u64)(g0+g1)-h0-h2;
	h0_1 = f2*(u64)g2;
	h2_1 = f3*(u64)g3;
	h1_1 = (f2+f3)*(u64)(g2+g3)-h0_1-h2_1;
	f4 = f0+f2;
	g4 = g0+g2;
	f5 = f1+f3;
	g5 = g1+g3; 
	h0_2 = f4*(u64)g4;
	h2_2 = f5*(u64)g5;
	h1_2 = (f4+f5)*(u64)(g4+g5)-h0_2-h2_2;
	h0_2 = h0_2 - h0_1 - h0;
	h1_2 = h1_2 - h1_1 - h1;
	h2_2 = h2_2 - h2_1 - h2;
	h0_t0 = h0;
	h1_t0 = h1;
	h2_t0 = h2 + h0_2;
	h3_t0 = h1_2;
	h4_t0 = h0_1 + h2_2;
	h5_t0 = h1_1;
	h6_t0 = h2_1;

	u32 f0_1 = m->v[4];
	u32 f1_1 = m->v[5];
	u32 f2_1 = m->v[6];
	u32 f3_1 = m->v[7];
	
	u32 g0_1 = n->v[4];
	u32 g1_1 = n->v[5];
	u32 g2_1 = n->v[6];
	u32 g3_1 = n->v[7];
	
	u64 h0_t1,h1_t1,h2_t1,h3_t1,h4_t1,h5_t1,h6_t1;
	h0 = f0_1*(u64)g0_1;
	h2 = f1_1*(u64)g1_1;
	h1 = (f0_1+f1_1)*(u64)(g0_1+g1_1)-h0-h2;
	h0_1 = f2_1*(u64)g2_1;
	h2_1 = f3_1*(u64)g3_1;
	h1_1 = (f2_1+f3_1)*(u64)(g2_1+g3_1)-h0_1-h2_1;
	f4 = f0_1+f2_1;
	g4 = g0_1+g2_1;
	f5 = f1_1+f3_1;
	g5 = g1_1+g3_1; 
	h0_2 = f4*(u64)g4;
	h2_2 = f5*(u64)g5;
	h1_2 = (f4+f5)*(u64)(g4+g5)-h0_2-h2_2;
	h0_2 = h0_2 - h0_1 - h0;
	h1_2 = h1_2 - h1_1 - h1;
	h2_2 = h2_2 - h2_1 - h2;
	h0_t1 = h0;
	h1_t1 = h1;
	h2_t1 = h2 + h0_2;
	h3_t1 = h1_2;
	h4_t1 = (h0_1 + h2_2);
	h5_t1 = h1_1;
	h6_t1 = h2_1;

	u32 f0_2 = f0 + f0_1;
	u32 f1_2 = f1 + f1_1;
	u32 f2_2 = f2 + f2_1;
	u32 f3_2 = f3 + f3_1;
	u32 g0_2 = g0 + g0_1;
	u32 g1_2 = g1 + g1_1;
	u32 g2_2 = g2 + g2_1;
	u32 g3_2 = g3 + g3_1;

	u64 h0_t2,h1_t2,h2_t2,h3_t2,h4_t2,h5_t2,h6_t2;
	h0 = f0_2*(u64)g0_2; 
	h2 = f1_2*(u64)g1_2;
	h1 = (f0_2+f1_2)*(u64)(g0_2+g1_2)-h0-h2;
	h0_1 = f2_2*(u64)g2_2;
	h2_1 = f3_2*(u64)g3_2;
	h1_1 = (f2_2+f3_2)*(u64)(g2_2+g3_2)-h0_1-h2_1;
	f4 = f0_2+f2_2;
	g4 = g0_2+g2_2;
	f5 = f1_2+f3_2;
	g5 = g1_2+g3_2; 
	h0_2 = f4*(u64)g4;
	h2_2 = f5*(u64)g5;
	h1_2 = (f4+f5)*(u64)(g4+g5)-h0_2-h2_2;
	h0_2 = h0_2 - h0_1 - h0;
	h1_2 = h1_2 - h1_1 - h1;
	h2_2 = h2_2 - h2_1 - h2;
	h0_t2 = h0 - h0_t0 - h0_t1;
	h1_t2 = h1 - h1_t0 - h1_t1;
	h2_t2 = h2 + h0_2  - h2_t0 - h2_t1;
	h3_t2 = h1_2 - h3_t0 - h3_t1;
	h4_t2 = h0_1 + h2_2 - h4_t0 - h4_t1;
	h5_t2 = h1_1 - h5_t0 - h5_t1;
	h6_t2 = h2_1 - h6_t0 - h6_t1 ;

	u64 t00,t01,t02,t03,t04,t05,t06,t07,t08,t09,t10,t11,t12,t13,t14,t15,t16,t17;
	u64 t00r,t01r,t02r,t03r,t04r,t05r,t06r,t07r;
	u64 t;
	t00 = h0_t0;
	t01 = h1_t0;
	t02 = h2_t0;
	t03 = h3_t0;
	t04 = h4_t0 + h0_t2;
	t05 = h5_t0 + h1_t2;
	t06 = h6_t0 + h2_t2;
	t07 = h3_t2;
	
	t08 = h4_t2 + h0_t1;
	t09 = h5_t2 + h1_t1;
	t10 = h6_t2 + h2_t1;
	t11 = h3_t1;
	t12 = h4_t1;
	t13 = h5_t1;
	t14 = h6_t1;
	
	u32 f8 = m->v[8];
	u32 g8 = n->v[8];
	

	t08 = t08 + f8*(u64)g0    + g8*(u64)f0;
	t09 = t09 + f8*(u64)g1    + g8*(u64)f1;
	t10 = t10 + f8*(u64)g2    + g8*(u64)f2;
	t11 = t11 + f8*(u64)g3    + g8*(u64)f3;
	t12 = t12 + f8*(u64)g0_1  + g8*(u64)f0_1;
	t13 = t13 + f8*(u64)g1_1  + g8*(u64)f1_1;
	t14 = t14 + f8*(u64)g2_1  + g8*(u64)f2_1; 
	t15 = f8*(u64)g3_1  + g8*(u64)f3_1;
	t16 = f8*(u64)g8;
	
	t00r = 18*t09;
	t01r = 18*t10;
	t02r = 18*t11;
	t03r = 18*t12;
	t04r = 18*t13;
	t05r = 18*t14;
	t06r = 18*t15;
	t07r = 18*t16;
	
	t00 = t00 + t00r;
	t01 = t01 + t01r;
	t02 = t02 + t02r;
	t03 = t03 + t03r;
	t04 = t04 + t04r;
	t05 = t05 + t05r;
	t06 = t06 + t06r;
	t07 = t07 + t07r;
	
	

	t = t00 >> 28; t00 = t00 & 0xfffffff; t01 = t01 + t;
	t = t01 >> 28; t01 = t01 & 0xfffffff; t02 = t02 + t;
	t = t02 >> 28; t02 = t02 & 0xfffffff; t03 = t03 + t; 
	t = t03 >> 28; t03 = t03 & 0xfffffff; t04 = t04 + t; 
	t = t04 >> 28; t04 = t04 & 0xfffffff; t05 = t05 + t; 
	t = t05 >> 28; t05 = t05 & 0xfffffff; t06 = t06 + t; 
	t = t06 >> 28; t06 = t06 & 0xfffffff; t07 = t07 + t; 
	t = t07 >> 28; t07 = t07 & 0xfffffff; t08 = t08 + t; 
	t = t08 >> 27; t08 = t08 & 0x7ffffff; t00 = t00 + 9*t; 
	t = t00 >> 28; t00 = t00 & 0xfffffff; t01 = t01 + t;  


	r32->v[0] = t00;
	r32->v[1] = t01;
	r32->v[2] = t02;
	r32->v[3] = t03;
	r32->v[4] = t04;
	r32->v[5] = t05;
	r32->v[6] = t06;
	r32->v[7] = t07;
	r32->v[8] = t08;
}


inline void sq_gfe(gfe *r32, gfe *m){
	u32 f0 = m->v[0];
	u32 f1 = m->v[1];
	u32 f2 = m->v[2];
	u32 f3 = m->v[3];
	u32 f4,f5;

	u64 h0_t0,h1_t0,h2_t0,h3_t0,h4_t0,h5_t0,h6_t0;
	u64 h0,h1,h2,h3,h4,h5,h6,h7;
	u64 h0_1,h1_1,h2_1,h3_1,h4_1,h5_1,h6_1,h7_1;
	u64 h0_2,h1_2,h2_2;
	h0 = f0*(u64)f0;
	h2 = f1*(u64)f1;
	h1 = 2*f0*(u64)f1;
	h0_1 = f2*(u64)f2;
	h2_1 = f3*(u64)f3;
	h1_1 = 2*f2*(u64)f3;
	f4 = f0+f2;
	f5  = f1+f3;
	h0_2 = f4*(u64)f4;
	h2_2 = f5*(u64)f5;
	h1_2 = 2*f4*(u64)f5;
	h0_2 = h0_2 - h0_1 - h0;
	h1_2 = h1_2 - h1_1 - h1;
	h2_2 = h2_2 - h2_1 - h2;
	h0_t0 = h0;
	h1_t0 = h1;
	h2_t0 = h2 + h0_2;
	h3_t0 = h1_2;
	h4_t0 = h0_1 + h2_2;
	h5_t0 = h1_1;
	h6_t0 = h2_1;

	u32 f0_1 = m->v[4];
	u32 f1_1 = m->v[5];
	u32 f2_1 = m->v[6];
	u32 f3_1 = m->v[7];
	
	u64 h0_t1,h1_t1,h2_t1,h3_t1,h4_t1,h5_t1,h6_t1;
	h0 = f0_1*(u64)f0_1;
	h2 = f1_1*(u64)f1_1;
	h1 = 2*f0_1*(u64)f1_1;
	h0_1 = f2_1*(u64)f2_1;
	h2_1 = f3_1*(u64)f3_1;
	h1_1 = 2*f2_1*(u64)f3_1;
	f4 = f0_1+f2_1;
	f5 = f1_1+f3_1;
	h0_2 = f4*(u64)f4;
	h2_2 = f5*(u64)f5;
	h1_2 = 2*f4*(u64)f5;
	h0_2 = h0_2 - h0_1 - h0;
	h1_2 = h1_2 - h1_1 - h1;
	h2_2 = h2_2 - h2_1 - h2;
	h0_t1 = h0;
	h1_t1 = h1;
	h2_t1 = h2 + h0_2;
	h3_t1 = h1_2;
	h4_t1 = (h0_1 + h2_2);
	h5_t1 = h1_1;
	h6_t1 = h2_1;

	u32 f0_2 = f0 + f0_1;
	u32 f1_2 = f1 + f1_1;
	u32 f2_2 = f2 + f2_1;
	u32 f3_2 = f3 + f3_1;
	

	u64 h0_t2,h1_t2,h2_t2,h3_t2,h4_t2,h5_t2,h6_t2;
	h0 = f0_2*(u64)f0_2; 
	h2 = f1_2*(u64)f1_2;
	h1 = 2*f0_2*(u64)f1_2;
	h0_1 = f2_2*(u64)f2_2;
	h2_1 = f3_2*(u64)f3_2;
	h1_1 = 2*f2_2*(u64)f3_2;
	f4 = f0_2+f2_2;
	f5 = f1_2+f3_2;
	h0_2 = f4*(u64)f4;
	h2_2 = f5*(u64)f5;
	h1_2 = 2*f4*(u64)f5;
	h0_2 = h0_2 - h0_1 - h0;
	h1_2 = h1_2 - h1_1 - h1;
	h2_2 = h2_2 - h2_1 - h2;
	h0_t2 = h0 - h0_t0 - h0_t1;
	h1_t2 = h1 - h1_t0 - h1_t1;
	h2_t2 = h2 + h0_2  - h2_t0 - h2_t1;
	h3_t2 = h1_2 - h3_t0 - h3_t1;
	h4_t2 = h0_1 + h2_2 - h4_t0 - h4_t1;
	h5_t2 = h1_1 - h5_t0 - h5_t1;
	h6_t2 = h2_1 - h6_t0 - h6_t1 ;

	u64 t00,t01,t02,t03,t04,t05,t06,t07,t08,t09,t10,t11,t12,t13,t14,t15,t16,t17;
	u64 t00r,t01r,t02r,t03r,t04r,t05r,t06r,t07r;
	u64 t;
	t00 = h0_t0;
	t01 = h1_t0;
	t02 = h2_t0;
	t03 = h3_t0;
	t04 = h4_t0 + h0_t2;
	t05 = h5_t0 + h1_t2;
	t06 = h6_t0 + h2_t2;
	t07 = h3_t2;
	
	t08 = h4_t2 + h0_t1;
	t09 = h5_t2 + h1_t1;
	t10 = h6_t2 + h2_t1;
	t11 = h3_t1;
	t12 = h4_t1;
	t13 = h5_t1;
	t14 = h6_t1;
	
	u32 f8 = m->v[8];

	t08 = t08 + 2*f8*(u64)f0;
	t09 = t09 + 2*f8*(u64)f1;
	t10 = t10 + 2*f8*(u64)f2;
	t11 = t11 + 2*f8*(u64)f3;
	t12 = t12 + 2*f8*(u64)f0_1;
	t13 = t13 + 2*f8*(u64)f1_1;
	t14 = t14 + 2*f8*(u64)f2_1; 
	t15 = 2*f8*(u64)f3_1;
	t16 = f8*(u64)f8;
	
	t00r = 18*t09;
	t01r = 18*t10;
	t02r = 18*t11;
	t03r = 18*t12;
	t04r = 18*t13;
	t05r = 18*t14;
	t06r = 18*t15;
	t07r = 18*t16;
	
	t00 = t00 + t00r;
	t01 = t01 + t01r;
	t02 = t02 + t02r;
	t03 = t03 + t03r;
	t04 = t04 + t04r;
	t05 = t05 + t05r;
	t06 = t06 + t06r;
	t07 = t07 + t07r;
	
	

	t = t00 >> 28; t00 = t00 & 0xfffffff; t01 = t01 + t;
	t = t01 >> 28; t01 = t01 & 0xfffffff; t02 = t02 + t;
	t = t02 >> 28; t02 = t02 & 0xfffffff; t03 = t03 + t; 
	t = t03 >> 28; t03 = t03 & 0xfffffff; t04 = t04 + t; 
	t = t04 >> 28; t04 = t04 & 0xfffffff; t05 = t05 + t; 
	t = t05 >> 28; t05 = t05 & 0xfffffff; t06 = t06 + t; 
	t = t06 >> 28; t06 = t06 & 0xfffffff; t07 = t07 + t; 
	t = t07 >> 28; t07 = t07 & 0xfffffff; t08 = t08 + t; 
	t = t08 >> 27; t08 = t08 & 0x7ffffff; t00 = t00 + 9*t; 
	t = t00 >> 28; t00 = t00 & 0xfffffff; t01 = t01 + t;  


	r32->v[0] = t00;
	r32->v[1] = t01;
	r32->v[2] = t02;
	r32->v[3] = t03;
	r32->v[4] = t04;
	r32->v[5] = t05;
	r32->v[6] = t06;
	r32->v[7] = t07;
	r32->v[8] = t08;
}

#define ADD4(R0,R1,R2,R3,A0,A1,A2,A3,B0,B1,B2,B3) {ADD(R0,A0,B0); ADD(R1,A1,B1); ADD(R2,A2,B2); ADD(R3,A3,B3);}

#define MULT4(C0,C1,C2,C3,C4,C5,C6,F0,F1,F2,F3,G0,G1,G2,G3){ \
	vec F4,F5,F0F1,F2F3,F4F5; \
	vec G4,G5,G0G1,G2G3,G4G5; \
	vec H0,H1,H2; \
	vec H0_1,H1_1,H2_1; \
	vec H0_2,H1_2,H2_2; \
	vec T0,T1,T2; \
\
	MULT(H0,F0,G0); \
	MULT(H2,F1,G1); \
	ADD(F0F1,F0,F1); \
	ADD(G0G1,G0,G1); \
	MULT(T0,F0F1,G0G1); \
	ADD(T1,H0,H2); \
	SUB(H1,T0,T1); \
\
	MULT(H0_1,F2,G2); \
	MULT(H2_1,F3,G3); \
	ADD(F2F3,F2,F3); \
	ADD(G2G3,G2,G3); \
	MULT(T0,F2F3,G2G3); \
	ADD(T1,H0_1,H2_1); \
	SUB(H1_1,T0,T1); \
\
	ADD(F4,F0,F2); \
	ADD(G4,G0,G2); \
	ADD(F5,F1,F3); \
	ADD(G5,G1,G3); \
\
	MULT(H0_2,F4,G4); \
	MULT(H2_2,F5,G5); \
	ADD(F4F5,F4,F5); \
	ADD(G4G5,G4,G5); \
	MULT(T0,F4F5,G4G5); \
	ADD(T1,H0_2,H2_2); \
	SUB(H1_2,T0,T1); \
\
	ADD(T0,H0_1,H0); \
	ADD(T1,H1_1,H1); \
	ADD(T2,H2_1,H2); \
	SUB(H0_2,H0_2,T0); \
	SUB(H1_2,H1_2,T1); \
	SUB(H2_2,H2_2,T2); \
\
	C0 = H0; \
	C1 = H1; \
	ADD(C2,H2,H0_2); \
	C3 = H1_2; \
	ADD(C4,H0_1, H2_2); \
	C5 = H1_1; \
	C6 = H2_1; \
}

#define SQ4(C0,C1,C2,C3,C4,C5,C6,F0,F1,F2,F3){ \
	vec F4,F5,F0F1,F2F3,F4F5; \
	vec G4,G5,G0G1,G2G3,G4G5; \
	vec H0,H1,H2; \
	vec H0_1,H1_1,H2_1; \
	vec H0_2,H1_2,H2_2; \
	vec T0,T1,T2; \
\
	MULT(H0,F0,F0); \
	MULT(H2,F1,F1); \
	MULT(F0F1,F0,F1); \
	SHIFTL(H1,F0F1,1); \
\
	MULT(H0_1,F2,F2); \
	MULT(H2_1,F3,F3); \
	MULT(F2F3,F2,F3); \
	SHIFTL(H1_1,F2F3,1); \
\
	ADD(F4,F0,F2); \
	ADD(F5,F1,F3); \
\
	MULT(H0_2,F4,F4); \
	MULT(H2_2,F5,F5); \
	MULT(F4F5,F4,F5); \
	SHIFTL(H1_2,F4F5,1); \
\
	ADD(T0,H0_1,H0); \
	ADD(T1,H1_1,H1); \
	ADD(T2,H2_1,H2); \
	SUB(H0_2,H0_2,T0); \
	SUB(H1_2,H1_2,T1); \
	SUB(H2_2,H2_2,T2); \
\
	C0 = H0; \
	C1 = H1; \
	ADD(C2,H2,H0_2); \
	C3 = H1_2; \
	ADD(C4,H0_1, H2_2); \
	C5 = H1_1; \
	C6 = H2_1; \
}

#define REDUCE(TEMP) {\
\
	vec t00r,t01r,t02r,t03r,t04r,t05r,t06r,t07r,t08r; \
	vec _18t00r,_18t01r,_18t02r,_18t03r,_18t04r,_18t05r,_18t06r,_18t07r,_18t08r; \
	vec te,tr; \
 \
	_18t00r = _mm256_slli_epi64(TEMP[9],3); \
	_18t00r = _mm256_add_epi64(_18t00r,TEMP[9]); _18t00r = _mm256_add_epi64(_18t00r,_18t00r); \
	_18t01r = _mm256_slli_epi64(TEMP[10],3); \
	_18t01r = _mm256_add_epi64(_18t01r,TEMP[10]); _18t01r = _mm256_add_epi64(_18t01r,_18t01r); \
	_18t02r = _mm256_slli_epi64(TEMP[11],3);	 \
	_18t02r = _mm256_add_epi64(_18t02r,TEMP[11]); _18t02r = _mm256_add_epi64(_18t02r,_18t02r); \
	_18t03r = _mm256_slli_epi64(TEMP[12],3); \
	_18t03r = _mm256_add_epi64(_18t03r,TEMP[12]); _18t03r = _mm256_add_epi64(_18t03r,_18t03r); \
	_18t04r = _mm256_slli_epi64(TEMP[13],3); \
	_18t04r = _mm256_add_epi64(_18t04r,TEMP[13]); _18t04r = _mm256_add_epi64(_18t04r,_18t04r); \
	_18t05r = _mm256_slli_epi64(TEMP[14],3); \
	_18t05r = _mm256_add_epi64(_18t05r,TEMP[14]); _18t05r = _mm256_add_epi64(_18t05r,_18t05r); \
	_18t06r = _mm256_slli_epi64(TEMP[15],3); \
	_18t06r = _mm256_add_epi64(_18t06r,TEMP[15]); _18t06r = _mm256_add_epi64(_18t06r,_18t06r); \
	_18t07r = _mm256_slli_epi64(TEMP[16],3); \
	_18t07r = _mm256_add_epi64(_18t07r,TEMP[16]); _18t07r = _mm256_add_epi64(_18t07r,_18t07r); \
 \
	TEMP[0] = _mm256_add_epi64(TEMP[0],_18t00r); \
	TEMP[1] = _mm256_add_epi64(TEMP[1],_18t01r); \
	TEMP[2] = _mm256_add_epi64(TEMP[2],_18t02r); \
	TEMP[3] = _mm256_add_epi64(TEMP[3],_18t03r); \
	TEMP[4] = _mm256_add_epi64(TEMP[4],_18t04r); \
	TEMP[5] = _mm256_add_epi64(TEMP[5],_18t05r); \
	TEMP[6] = _mm256_add_epi64(TEMP[6],_18t06r); \
	TEMP[7] = _mm256_add_epi64(TEMP[7],_18t07r); \
 \
	te = _mm256_srli_epi64(TEMP[0],28); TEMP[0] = _mm256_and_si256(TEMP[0],mask28); TEMP[1] = _mm256_add_epi64(TEMP[1],te); \
	te = _mm256_srli_epi64(TEMP[1],28); TEMP[1] = _mm256_and_si256(TEMP[1],mask28); TEMP[2] = _mm256_add_epi64(TEMP[2],te); \
	te = _mm256_srli_epi64(TEMP[2],28); TEMP[2] = _mm256_and_si256(TEMP[2],mask28); TEMP[3] = _mm256_add_epi64(TEMP[3],te); \
	te = _mm256_srli_epi64(TEMP[3],28); TEMP[3] = _mm256_and_si256(TEMP[3],mask28); TEMP[4] = _mm256_add_epi64(TEMP[4],te); \
	te = _mm256_srli_epi64(TEMP[4],28); TEMP[4] = _mm256_and_si256(TEMP[4],mask28); TEMP[5] = _mm256_add_epi64(TEMP[5],te); \
	te = _mm256_srli_epi64(TEMP[5],28); TEMP[5] = _mm256_and_si256(TEMP[5],mask28); TEMP[6] = _mm256_add_epi64(TEMP[6],te); \
	te = _mm256_srli_epi64(TEMP[6],28); TEMP[6] = _mm256_and_si256(TEMP[6],mask28); TEMP[7] = _mm256_add_epi64(TEMP[7],te); \
	te = _mm256_srli_epi64(TEMP[7],28); TEMP[7] = _mm256_and_si256(TEMP[7],mask28); TEMP[8] = _mm256_add_epi64(TEMP[8],te); \
	te = _mm256_srli_epi64(TEMP[8],27); TEMP[8] = _mm256_and_si256(TEMP[8],mask27);  \
	tr = _mm256_slli_epi64(te,3); te = _mm256_add_epi64(tr,te); \
	TEMP[0] = _mm256_add_epi64(TEMP[0],te); \
	te = _mm256_srli_epi64(TEMP[0],28); TEMP[0] = _mm256_and_si256(TEMP[0],mask28); TEMP[1] = _mm256_add_epi64(TEMP[1],te); \
 \
}

inline void mul_gfe4(gfe4x *r64, gfe4x *m, gfe4x *n){
	vec f0,f1,f2,f3,f4,f5;
	vec g0,g1,g2,g3,g4,g5;
	vec f0_1,f1_1,f2_1,f3_1;
	vec g0_1,g1_1,g2_1,g3_1;
	vec f0_2,f1_2,f2_2,f3_2;
	vec g0_2,g1_2,g2_2,g3_2;
	vec h0_t0,h1_t0,h2_t0,h3_t0,h4_t0,h5_t0,h6_t0;
	vec h0_t1,h1_t1,h2_t1,h3_t1,h4_t1,h5_t1,h6_t1;
	vec h0_t2,h1_t2,h2_t2,h3_t2,h4_t2,h5_t2,h6_t2;
	vec t[17];

	f0 = m->v[0];  f1 = m->v[1];  f2 = m->v[2];  f3 = m->v[3];
	f0_1 = m->v[4];	 f1_1 = m->v[5];  f2_1 = m->v[6];  f3_1 = m->v[7];
	ADD4(f0_2,f1_2,f2_2,f3_2,f0,f1,f2,f3,f0_1,f1_1,f2_1,f3_1);
		
	g0 = n->v[0];  g1 = n->v[1];  g2 = n->v[2];  g3 = n->v[3];
	g0_1 = n->v[4];  g1_1 = n->v[5];  g2_1 = n->v[6];  g3_1 = n->v[7];
	ADD4(g0_2,g1_2,g2_2,g3_2,g0,g1,g2,g3,g0_1,g1_1,g2_1,g3_1);
	
	MULT4(h0_t0,h1_t0,h2_t0,h3_t0,h4_t0,h5_t0,h6_t0,f0,f1,f2,f3,g0,g1,g2,g3);
	MULT4(h0_t1,h1_t1,h2_t1,h3_t1,h4_t1,h5_t1,h6_t1,f0_1,f1_1,f2_1,f3_1,g0_1,g1_1,g2_1,g3_1);
	MULT4(h0_t2,h1_t2,h2_t2,h3_t2,h4_t2,h5_t2,h6_t2,f0_2,f1_2,f2_2,f3_2,g0_2,g1_2,g2_2,g3_2);


	ADD(t[0],h0_t0,h0_t1); ADD(t[1],h1_t0,h1_t1); ADD(t[2],h2_t0,h2_t1); ADD(t[3],h3_t0,h3_t1); 
	ADD(t[4],h4_t0,h4_t1); ADD(t[5],h5_t0,h5_t1); ADD(t[6],h6_t0,h6_t1);
	SUB(h0_t2,h0_t2,t[0]); SUB(h1_t2,h1_t2,t[1]); SUB(h2_t2,h2_t2,t[2]); SUB(h3_t2,h3_t2,t[3]);
	SUB(h4_t2,h4_t2,t[4]); SUB(h5_t2,h5_t2,t[5]); SUB(h6_t2,h6_t2,t[6]);	

	t[0]  = h0_t0; t[1]  = h1_t0; t[2]  = h2_t0; t[3]  = h3_t0; 
	ADD(t[4],h4_t0,h0_t2); ADD(t[5],h5_t0,h1_t2); ADD(t[6],h6_t0,h2_t2);
	t[7]  = h3_t2;
	ADD(t[8],h4_t2,h0_t1); ADD(t[9],h5_t2,h1_t1); ADD(t[10],h6_t2,h2_t1);
	t[11] = h3_t1; t[12] = h4_t1; t[13] = h5_t1; t[14] = h6_t1;

	vec f8 = m->v[8];
	vec g8 = n->v[8];
	vec te[22];
	
	MULT(te[0],f8,g0);MULT(te[1],g8,f0);
	MULT(te[3],f8,g1);MULT(te[4],g8,f1);
	MULT(te[6],f8,g2);MULT(te[7],g8,f2);
	MULT(te[9],f8,g3);MULT(te[10],g8,f3);
	MULT(te[12],f8,g0_1);MULT(te[13],g8,f0_1);
	MULT(te[15],f8,g1_1);MULT(te[16],g8,f1_1);
	MULT(te[18],f8,g2_1);MULT(te[19],g8,f2_1);
	MULT(te[21],f8,g3_1);MULT(te[22],g8,f3_1);
	MULT(t[16],f8,g8);
	
	ADD(te[2],te[0],te[1]);		ADD(t[8],t[8],te[2]);
	ADD(te[5],te[3],te[4]);		ADD(t[9],t[9],te[5]);
	ADD(te[8],te[6],te[7]);		ADD(t[10],t[10],te[8]);
	ADD(te[11],te[9],te[10]);	ADD(t[11],t[11],te[11]);
	ADD(te[14],te[12],te[13]);	ADD(t[12],t[12],te[14]);
	ADD(te[17],te[15],te[16]);	ADD(t[13],t[13],te[17]);
	ADD(te[20],te[18],te[19]);	ADD(t[14],t[14],te[20]); 
	ADD(t[15],te[21],te[22]);
	


	REDUCE(t);
	r64->v[0] = t[0];
	r64->v[1] = t[1];
	r64->v[2] = t[2];
	r64->v[3] = t[3];
	r64->v[4] = t[4];
	r64->v[5] = t[5];
	r64->v[6] = t[6];
	r64->v[7] = t[7];
	r64->v[8] = t[8];
}

inline void sq_gfe4(gfe4x *r64, gfe4x *m){
	vec f0,f1,f2,f3,f4,f5;
	vec f0_1,f1_1,f2_1,f3_1;
	vec f0_2,f1_2,f2_2,f3_2;
	vec h0_t0,h1_t0,h2_t0,h3_t0,h4_t0,h5_t0,h6_t0;
	vec h0_t1,h1_t1,h2_t1,h3_t1,h4_t1,h5_t1,h6_t1;
	vec h0_t2,h1_t2,h2_t2,h3_t2,h4_t2,h5_t2,h6_t2;
	vec t[17];

	f0 = m->v[0];  f1 = m->v[1];  f2 = m->v[2];  f3 = m->v[3];
	f0_1 = m->v[4];	 f1_1 = m->v[5];  f2_1 = m->v[6];  f3_1 = m->v[7];
	ADD4(f0_2,f1_2,f2_2,f3_2,f0,f1,f2,f3,f0_1,f1_1,f2_1,f3_1);
		
	SQ4(h0_t0,h1_t0,h2_t0,h3_t0,h4_t0,h5_t0,h6_t0,f0,f1,f2,f3);
	SQ4(h0_t1,h1_t1,h2_t1,h3_t1,h4_t1,h5_t1,h6_t1,f0_1,f1_1,f2_1,f3_1);
	SQ4(h0_t2,h1_t2,h2_t2,h3_t2,h4_t2,h5_t2,h6_t2,f0_2,f1_2,f2_2,f3_2);


	ADD(t[0],h0_t0,h0_t1); ADD(t[1],h1_t0,h1_t1); ADD(t[2],h2_t0,h2_t1); ADD(t[3],h3_t0,h3_t1); 
	ADD(t[4],h4_t0,h4_t1); ADD(t[5],h5_t0,h5_t1); ADD(t[6],h6_t0,h6_t1);
	SUB(h0_t2,h0_t2,t[0]); SUB(h1_t2,h1_t2,t[1]); SUB(h2_t2,h2_t2,t[2]); SUB(h3_t2,h3_t2,t[3]);
	SUB(h4_t2,h4_t2,t[4]); SUB(h5_t2,h5_t2,t[5]); SUB(h6_t2,h6_t2,t[6]);	

	t[0]  = h0_t0; t[1]  = h1_t0; t[2]  = h2_t0; t[3]  = h3_t0; 
	ADD(t[4],h4_t0,h0_t2); ADD(t[5],h5_t0,h1_t2); ADD(t[6],h6_t0,h2_t2);
	t[7]  = h3_t2;
	ADD(t[8],h4_t2,h0_t1); ADD(t[9],h5_t2,h1_t1); ADD(t[10],h6_t2,h2_t1);
	t[11] = h3_t1; t[12] = h4_t1; t[13] = h5_t1; t[14] = h6_t1;

	vec f8 = m->v[8];
	vec te[22];
	
	MULT(te[0],f8,f0);
	MULT(te[1],f8,f1);
	MULT(te[2],f8,f2);
	MULT(te[3],f8,f3);
	MULT(te[4],f8,f0_1);
	MULT(te[5],f8,f1_1);
	MULT(te[6],f8,f2_1);
	MULT(te[7],f8,f3_1);
	MULT(t[16],f8,f8);
	
	SHIFTL(te[8],te[0],1); ADD(t[8],t[8],te[8]);
	SHIFTL(te[9],te[1],1);	ADD(t[9],t[9],te[9]);
	SHIFTL(te[10],te[2],1);	ADD(t[10],t[10],te[10]);
	SHIFTL(te[11],te[3],1);	ADD(t[11],t[11],te[11]);
	SHIFTL(te[12],te[4],1);	ADD(t[12],t[12],te[12]);
	SHIFTL(te[13],te[5],1);	ADD(t[13],t[13],te[13]);
	SHIFTL(te[14],te[6],1);	ADD(t[14],t[14],te[14]); 
	SHIFTL(t[15],te[7],1);


	REDUCE(t);
	r64->v[0] = t[0];
	r64->v[1] = t[1];
	r64->v[2] = t[2];
	r64->v[3] = t[3];
	r64->v[4] = t[4];
	r64->v[5] = t[5];
	r64->v[6] = t[6];
	r64->v[7] = t[7];
	r64->v[8] = t[8];
}



const vec hadamardoffset[9] =   {{0, 0x1FFFFFEF, 0, 0x1FFFFFEF},
					{0, 0x1FFFFFFF, 0, 0x1FFFFFFF},
					{0, 0x1FFFFFFF, 0, 0x1FFFFFFF},
					{0, 0x1FFFFFFF, 0, 0x1FFFFFFF},
					{0, 0x1FFFFFFF, 0, 0x1FFFFFFF},
					{0, 0x1FFFFFFF, 0, 0x1FFFFFFF},
					{0, 0x1FFFFFFF, 0, 0x1FFFFFFF},
					{0, 0x1FFFFFFF, 0, 0x1FFFFFFF},
					{0, 0xFFFFFFF , 0, 0xFFFFFFF}};


inline void gfe4x_hadamard(gfe4x *op, gfe4x *ip){
  	int i;
	vec t[9];
	vec temp1,temp2,temp3,temp;

	temp = ip->v[0];
	temp2 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(2,2,0,0));
	temp3 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(3,3,1,1));
	temp = _mm256_add_epi32(_mm256_add_epi32(temp2,hadamardoffset[0]),_mm256_xor_si256(temp3,plusminusplusminus));
	t[0] = _mm256_and_si256(temp,and01);

	temp = ip->v[1];
	temp2 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(2,2,0,0));
	temp3 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(3,3,1,1));
	temp = _mm256_add_epi32(_mm256_add_epi32(temp2,hadamardoffset[1]),_mm256_xor_si256(temp3,plusminusplusminus));
	t[1] = _mm256_and_si256(temp,and01);

	temp = ip->v[2];
	temp2 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(2,2,0,0));
	temp3 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(3,3,1,1));
	temp = _mm256_add_epi32(_mm256_add_epi32(temp2,hadamardoffset[2]),_mm256_xor_si256(temp3,plusminusplusminus));
	t[2] = _mm256_and_si256(temp,and01);

	temp = ip->v[3];
	temp2 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(2,2,0,0));
	temp3 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(3,3,1,1));
	temp = _mm256_add_epi32(_mm256_add_epi32(temp2,hadamardoffset[3]),_mm256_xor_si256(temp3,plusminusplusminus));
	t[3] = _mm256_and_si256(temp,and01);

	temp = ip->v[4];
	temp2 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(2,2,0,0));
	temp3 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(3,3,1,1));
	temp = _mm256_add_epi32(_mm256_add_epi32(temp2,hadamardoffset[4]),_mm256_xor_si256(temp3,plusminusplusminus));
	t[4] = _mm256_and_si256(temp,and01);

	temp = ip->v[5];
	temp2 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(2,2,0,0));
	temp3 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(3,3,1,1));
	temp = _mm256_add_epi32(_mm256_add_epi32(temp2,hadamardoffset[5]),_mm256_xor_si256(temp3,plusminusplusminus));
	t[5] = _mm256_and_si256(temp,and01);

	temp = ip->v[6];
	temp2 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(2,2,0,0));
	temp3 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(3,3,1,1));
	temp = _mm256_add_epi32(_mm256_add_epi32(temp2,hadamardoffset[6]),_mm256_xor_si256(temp3,plusminusplusminus));
	t[6] = _mm256_and_si256(temp,and01);

	temp = ip->v[7];
	temp2 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(2,2,0,0));
	temp3 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(3,3,1,1));
	temp = _mm256_add_epi32(_mm256_add_epi32(temp2,hadamardoffset[7]),_mm256_xor_si256(temp3,plusminusplusminus));
	t[7] = _mm256_and_si256(temp,and01);

	temp = ip->v[8];
	temp2 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(2,2,0,0));
	temp3 = _mm256_permute4x64_epi64 (temp,_MM_SHUFFLE(3,3,1,1));
	temp = _mm256_add_epi32(_mm256_add_epi32(temp2,hadamardoffset[8]),_mm256_xor_si256(temp3,plusminusplusminus));
	t[8] = _mm256_and_si256(temp,and01);


	
	vec te, tr;
	te = _mm256_srli_epi64(t[0],28); t[0] = _mm256_and_si256(t[0],mask28); t[1] = _mm256_add_epi64(t[1],te);
	te = _mm256_srli_epi64(t[1],28); t[1] = _mm256_and_si256(t[1],mask28); t[2] = _mm256_add_epi64(t[2],te);
	te = _mm256_srli_epi64(t[2],28); t[2] = _mm256_and_si256(t[2],mask28); t[3] = _mm256_add_epi64(t[3],te);
	te = _mm256_srli_epi64(t[3],28); t[3] = _mm256_and_si256(t[3],mask28); t[4] = _mm256_add_epi64(t[4],te);
	te = _mm256_srli_epi64(t[4],28); t[4] = _mm256_and_si256(t[4],mask28); t[5] = _mm256_add_epi64(t[5],te);
	te = _mm256_srli_epi64(t[5],28); t[5] = _mm256_and_si256(t[5],mask28); t[6] = _mm256_add_epi64(t[6],te);
	te = _mm256_srli_epi64(t[6],28); t[6] = _mm256_and_si256(t[6],mask28); t[7] = _mm256_add_epi64(t[7],te);
	te = _mm256_srli_epi64(t[7],28); t[7] = _mm256_and_si256(t[7],mask28); t[8] = _mm256_add_epi64(t[8],te);
	te = _mm256_srli_epi64(t[8],27); t[8] = _mm256_and_si256(t[8],mask27); 
	tr = _mm256_slli_epi64(te,3); te = _mm256_add_epi64(tr,te);
	t[0] = _mm256_add_epi64(t[0],te);
	te = _mm256_srli_epi64(t[0],28); t[0] = _mm256_and_si256(t[0],mask28); t[1] = _mm256_add_epi64(t[1],te);

	op->v[0] = t[0];
	op->v[1] = t[1];
	op->v[2] = t[2];
	op->v[3] = t[3];
	op->v[4] = t[4];
	op->v[5] = t[5];
	op->v[6] = t[6];
	op->v[7] = t[7];
	op->v[8] = t[8];

}



inline void mulconst_gfe4(gfe4x *r64, gfe4x *a, const vec *b){
	vec h0,h1,h2,h3,h4,h5,h6,h7,h8;
	
	h0 = _mm256_mul_epi32(a->v[0],*b);
	h1 = _mm256_mul_epi32(a->v[1],*b);
	h2 = _mm256_mul_epi32(a->v[2],*b);
	h3 = _mm256_mul_epi32(a->v[3],*b);
	h4 = _mm256_mul_epi32(a->v[4],*b);
	h5 = _mm256_mul_epi32(a->v[5],*b);
	h6 = _mm256_mul_epi32(a->v[6],*b);
	h7 = _mm256_mul_epi32(a->v[7],*b);
	h8 = _mm256_mul_epi32(a->v[8],*b);
	
	vec t,tr;
	t = _mm256_srli_epi64(h0,28); h0 = _mm256_and_si256(h0,mask28); h1 = _mm256_add_epi64(h1,t);
	t = _mm256_srli_epi64(h1,28); h1 = _mm256_and_si256(h1,mask28); h2 = _mm256_add_epi64(h2,t);
	t = _mm256_srli_epi64(h2,28); h2 = _mm256_and_si256(h2,mask28); h3 = _mm256_add_epi64(h3,t);
	t = _mm256_srli_epi64(h3,28); h3 = _mm256_and_si256(h3,mask28); h4 = _mm256_add_epi64(h4,t);
	t = _mm256_srli_epi64(h4,28); h4 = _mm256_and_si256(h4,mask28); h5 = _mm256_add_epi64(h5,t);
	t = _mm256_srli_epi64(h5,28); h5 = _mm256_and_si256(h5,mask28); h6 = _mm256_add_epi64(h6,t);
	t = _mm256_srli_epi64(h6,28); h6 = _mm256_and_si256(h6,mask28); h7 = _mm256_add_epi64(h7,t);
	t = _mm256_srli_epi64(h7,28); h7 = _mm256_and_si256(h7,mask28); h8 = _mm256_add_epi64(h8,t);
	t = _mm256_srli_epi64(h8,27); h8 = _mm256_and_si256(h8,mask27); 
	tr = _mm256_slli_epi64(t,3); t = _mm256_add_epi64(tr,t);
	h0 = _mm256_add_epi64(h0,t);
	t = _mm256_srli_epi64(h0,28); h0 = _mm256_and_si256(h0,mask28); h1 = _mm256_add_epi64(h1,t);

	r64->v[0] = h0;
	r64->v[1] = h1;
	r64->v[2] = h2;
	r64->v[3] = h3;
	r64->v[4] = h4;
	r64->v[5] = h5;
	r64->v[6] = h6;
	r64->v[7] = h7;
	r64->v[8] = h8;

}




inline unsigned int gt0(gfe *m){
	u32 r=0;
	int i;
	for(i=0;i<9;i++){
		r = r | m->v[i];
	}
	
	return r;
}


inline unsigned int ugtv(gfe *m, gfe *n){
	u32 r=0;

	int i;
	for(i=8;i>=0;i--){
		if (m->v[i] > n->v[i]){
			r = 1;
			break;
		}
		else if (m->v[i] < n->v[i])			
			break;
		else continue;
	}
	
	return r;
}

const unsigned int l28=0x10000000;
inline void div2(gfe *m){
	u32 temp;

	temp = m->v[8] & 1; m->v[8] = m->v[8] >> 1; m->v[7] = m->v[7] + temp*l28;
	temp = m->v[7] & 1; m->v[7] = m->v[7] >> 1; m->v[6] = m->v[6] + temp*l28;
	temp = m->v[6] & 1; m->v[6] = m->v[6] >> 1; m->v[5] = m->v[5] + temp*l28;
	temp = m->v[5] & 1; m->v[5] = m->v[5] >> 1; m->v[4] = m->v[4] + temp*l28;
	temp = m->v[4] & 1; m->v[4] = m->v[4] >> 1; m->v[3] = m->v[3] + temp*l28;
	temp = m->v[3] & 1; m->v[3] = m->v[3] >> 1; m->v[2] = m->v[2] + temp*l28;
	temp = m->v[2] & 1; m->v[2] = m->v[2] >> 1; m->v[1] = m->v[1] + temp*l28;
	temp = m->v[1] & 1; m->v[1] = m->v[1] >> 1; m->v[0] = m->v[0] + temp*l28;
	temp = m->v[0] & 1; m->v[0] = m->v[0] >> 1; 
	
}

static const unsigned int b28=0x10000000;

inline void mul2(gfe *m){
	u32 temp;

	m->v[0] = m->v[0] << 1; temp = m->v[0] >> 28; m->v[0] = m->v[0] & 0xfffffff;
	m->v[1] = m->v[1] << 1;	m->v[1] = m->v[1] + temp; temp = m->v[1] >> 28; m->v[1] = m->v[1] & 0xfffffff;
	m->v[2] = m->v[2] << 1; m->v[2] = m->v[2] + temp; temp = m->v[2] >> 28; m->v[2] = m->v[2] & 0xfffffff;
	m->v[3] = m->v[3] << 1; m->v[3] = m->v[3] + temp; temp = m->v[3] >> 28; m->v[3] = m->v[3] & 0xfffffff;
	m->v[4] = m->v[4] << 1; m->v[4] = m->v[4] + temp; temp = m->v[4] >> 28; m->v[4] = m->v[4] & 0xfffffff;
	m->v[5] = m->v[5] << 1; m->v[5] = m->v[5] + temp; temp = m->v[5] >> 28; m->v[5] = m->v[5] & 0xfffffff;
	m->v[6] = m->v[6] << 1; m->v[6] = m->v[6] + temp; temp = m->v[6] >> 28; m->v[6] = m->v[6] & 0xfffffff;
	m->v[7] = m->v[7] << 1; m->v[7] = m->v[7] + temp; temp = m->v[7] >> 28; m->v[7] = m->v[7] & 0xfffffff;
	m->v[8] = m->v[8] << 1; m->v[8] = m->v[8] + temp;

}


inline void addp(gfe *m, gfe *p){
	u32 temp;

	m->v[8] = m->v[8] + p->v[8];
	m->v[7] = m->v[7] + p->v[7];
	m->v[6] = m->v[6] + p->v[6];
	m->v[5] = m->v[5] + p->v[5];
	m->v[4] = m->v[4] + p->v[4];
	m->v[3] = m->v[3] + p->v[3];
	m->v[2] = m->v[2] + p->v[2];
	m->v[1] = m->v[1] + p->v[1];
	m->v[0] = m->v[0] + p->v[0];

}

inline void subuv(gfe *op, gfe *m, gfe *n){
	u32 b=0;
	u32 t;
	
	if(m->v[0] >= n->v[0])
		op->v[0] = m->v[0] - n->v[0];
	else{
		op->v[0] = (m->v[0] + 0x10000000) - n->v[0];
		b = 1;
	}
	t = n->v[1]+b;
	if(m->v[1] >= t){
		op->v[1] = m->v[1] - t;
		b = 0;
	}else{
		op->v[1] = (m->v[1] + 0x10000000) - t;
		b = 1;
	}

	t = n->v[2]+b;
	if(m->v[2] >= t){
		op->v[2] = m->v[2] - t;
		b = 0;
	}else{
		op->v[2] = (m->v[2] + 0x10000000) - t;
		b = 1;
	}
	t = n->v[3]+b;
	if(m->v[3] >= t){
		op->v[3] = m->v[3] - t;
		b = 0;
	}else{
		op->v[3] = (m->v[3] + 0x10000000) - t;
		b = 1;
	}
	t = n->v[4]+b;
	if(m->v[4] >= t){
		op->v[4] = m->v[4] - t;
		b = 0;
	}else{
		op->v[4] = (m->v[4] + 0x10000000) - t;
		b = 1;
	}
	t = n->v[5]+b;
	if(m->v[5] >= t){
		op->v[5] = m->v[5] - t;
		b = 0;
	}else{
		op->v[5] = (m->v[5] + 0x10000000) - t;
		b = 1;
	}
	t = n->v[6]+b;
	if(m->v[6] >= t){
		op->v[6] = m->v[6] - t;
		b = 0;
	}else{
		op->v[6] = (m->v[6] + 0x10000000) - t;
		b = 1;
	}
	t = n->v[7]+b;
	if(m->v[7] >= t){
		op->v[7] = m->v[7] - t;
		b = 0;
	}else{
		op->v[7] = (m->v[7] + 0x10000000) - t;
		b = 1;
	}
	op->v[8] = m->v[8] - n->v[8] - b;

}

inline void adduv(gfe *op, gfe *m, gfe *n){
	u32 temp;

	op->v[8] = m->v[8] + n->v[8];
	op->v[7] = m->v[7] + n->v[7];
	op->v[6] = m->v[6] + n->v[6];
	op->v[5] = m->v[5] + n->v[5];
	op->v[4] = m->v[4] + n->v[4];
	op->v[3] = m->v[3] + n->v[3];
	op->v[2] = m->v[2] + n->v[2];
	op->v[1] = m->v[1] + n->v[1];
	op->v[0] = m->v[0] + n->v[0];

	temp = op->v[0] >> 28; op->v[1] = op->v[1] + temp;     op->v[0] = op->v[0] & 0xfffffff;
	temp = op->v[1] >> 28; op->v[2] = op->v[2] + temp;     op->v[1] = op->v[1] & 0xfffffff;
	temp = op->v[2] >> 28; op->v[3] = op->v[3] + temp;     op->v[2] = op->v[2] & 0xfffffff;
	temp = op->v[3] >> 28; op->v[4] = op->v[4] + temp;     op->v[3] = op->v[3] & 0xfffffff;
	temp = op->v[4] >> 28; op->v[5] = op->v[5] + temp;     op->v[4] = op->v[4] & 0xfffffff;
	temp = op->v[5] >> 28; op->v[6] = op->v[6] + temp;     op->v[5] = op->v[5] & 0xfffffff;
	temp = op->v[6] >> 28; op->v[7] = op->v[7] + temp;     op->v[6] = op->v[6] & 0xfffffff;
	temp = op->v[7] >> 28; op->v[8] = op->v[8] + temp;     op->v[7] = op->v[7] & 0xfffffff;

}


inline void invert(gfe *op, gfe *m){
	gfe r = {0,0,0,0,0,0,0,0,0};
	gfe s = {1,0,0,0,0,0,0,0,0};
	int i,k = 0;
	gfe a = p;
	gfe b = *m;
	
	while (gt0(&b)){
		if ((a.v[0]&1) == 0){
			div2(&a);	
			mul2(&s);
		}else if((b.v[0]&1) == 0){
			div2(&b);
			mul2(&r);
		}else if(ugtv(&a, &b)){
			subuv(&a,&a,&b);
			div2(&a);
			adduv(&r,&r,&s);
			mul2(&s);
		}else {
			subuv(&b,&b,&a);
			div2(&b);
			adduv(&s,&r,&s);
			mul2(&r);
		}k = k+1;
	}

	if (ugtv(&r,&p))
		subuv(&r,&r,&p);


	for (i=1;i<=(k-251);i++){	
		if ((r.v[0]&1) == 0){
			div2(&r);
		}else{
			addp(&r,&p);		
			div2(&r);
		}
	}
	subuv(&r,&p,&r);

	mul_gfe(op, &r, &adjust_invert);
}



#endif
